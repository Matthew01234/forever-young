for i in range(1, 13, 1):
    print('AM ' + str(i))
for i in range(1, 13, 1):
       print('PM ' + str(i))