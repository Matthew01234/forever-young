tafel= input ('voer hier de tafel in die je wilt uitrekenen: ')

for i in range(1, 11, 1):
    print (i * int(tafel))
