for i in range(20, 50, 2):
    print (i)
    